# Hi-Kod Veri Bilimi 6. Atölye Projesi
Projeyi Yapanlar:
Büşra Hilalnur Taşkın, 
Hatice Eren, 
Nuray Karabulut, 
Şeyma Tezel
